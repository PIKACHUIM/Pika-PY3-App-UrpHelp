import os
import re
import time
import json
from urps_conf import *
from urps_outp import *
def urps_zdqk(http_main):
    os.system('cls')
    os.system('color 5f')
    print()
    print("----------------------------------------------自动抢课-----------------------------------------------")
    print()
    print("                         *请输入关键词，注意区分大小写以及中英文符号，请勿留空*")
    print()
    while 1:
        zdqk_inpu = input("[输入关键词]：")
        if len(zdqk_inpu) >= 1:
            break
        print("[输入不正确]：请重新输入")
    print()
    post_data = {
        "searchtj": zdqk_inpu,
        "xq": 0,
        "jc": 0,
        "kclbdm": ""
    }
    try:
        zyxk_data = http_main.get(http_urls_zyxk)
        if zyxk_data.text.find("自由选课") != -1:
            print("")
            print("[获取到课表]：成功进入课表页面")
        zyxk_data = http_main.post(http_urls_kclb, post_data)
    except:
        print("[严重的错误]：网络连接中断，请确保网络稳定")
        input("--------------------------------------------按回车键返回--------------------------------------------")
        return -2
    else:
        pass
    zyxk_tabs = json.loads(zyxk_data.text)
    zyxk_list = json.loads(zyxk_tabs['rwRxkZlList'])
    zyxk_nums = 0
    os.system('cls')
    print()
    print("----------------------------------------------搜索结果-----------------------------------------------")
    print()
    print("#                课程名           校区 余量  位置   教室    周数    时间    教师")
    print("-----------------------------------------------------------------------------------------------------")
    print()
    for zyxk_loop in zyxk_list:
        zyxk_nums += 1
        urps_oupt(zyxk_loop,zyxk_nums)
        if zyxk_nums%40==0:
            print()
            print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>按回车下一页>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
            input()
            os.system('cls')
            print()
            print("----------------------------------------------搜索结果-----------------------------------------------")
            print()
            print("#                课程名           校区 余量  位置   教室    周数    时间    教师")
            print("-----------------------------------------------------------------------------------------------------")
            print()
    if zyxk_nums == 0:
        print()
        print("**************************************列表为空，请检查输入内容**************************************")
        print()
        input("--------------------------------------------按回车键返回--------------------------------------------")
        return -1
    print("-----------------------------------------------------------------------------------------------------")
    print()
    zyxk_fatp = json.loads(zyxk_tabs['yxkclist'])
    zyxk_fxid = zyxk_fatp[0]['programPlanNumber']
    print("[请输入编号]：输入你要抢课最左侧的编号，输入exit或no返回主菜单")
    while 1:
        zyxk_choi = input("[请输入编号]：")
        if len(zyxk_choi) >= 1:
            if 'exit' in zyxk_choi or 'n' in zyxk_choi:
                return 1
            if bool(re.search('[a-z]', zyxk_choi)):
                print("[输入不正确]：请重新输入")
                continue
            zyxk_nump = int(zyxk_choi)
            if zyxk_nump in range(1, zyxk_nums + 1):
                zyxk_wait = zyxk_nump
                break
        print("[输入不正确]：请重新输入")
    print("")
    zyxk_dat1 = ""
    zyxk_dat2 = ""
    zyxk_dat3 = ""
    zyxk_nums = 0
    for zyxk_loop in zyxk_list:
        zyxk_nums += 1
        if zyxk_nums == zyxk_wait:
            print("[选中的课程]：将监听下列课程课余量：")
            print(str(zyxk_nums).rjust(2, ' '),
                  zyxk_loop['kcm'][0:8].rjust(8, ' '),
                  zyxk_loop['kkxqm'].ljust(2, ' '),
                  str(zyxk_loop['bkskyl']).rjust(3, ' '),
                  zyxk_loop['jxlm'][0:4].ljust(4, ' '),
                  zyxk_loop['jasm'][0:4].ljust(4, ' '),
                  end="")
            zyxk_chls = False
            for ch in zyxk_loop['jasm'][0:4]:
                if u'\u4e00' <= ch <= u'\u9fff':
                    zyxk_chls = True
            if zyxk_chls == False:
                print("    ", end="")
            print(
                zyxk_loop['sjdd'][0]['zcsm'].rjust(6, ' '),
                zyxk_loop['skjs'][0:3].ljust(3, ' ')
            )
            print("-----------------------------------------------------------------------------------------------------")
            print("")
            zyxk_dat1 = zyxk_loop['kcm']
            zyxk_dat2 = zyxk_loop['jasm']
            zyxk_dat3 = zyxk_loop['skjs']
    print("[刷新的间隔]：输入刷新间隔，表示每隔几秒检测一次，建议3~5秒")
    while 1:
        zyxk_tima = input("[请输入间隔]：")
        if len(zyxk_tima) >= 1:
            if 'exit' in zyxk_tima or 'n' in zyxk_tima:
                return 1
            if bool(re.search('[a-z]', zyxk_tima)):
                print("[输入不正确]：请重新输入")
                continue
            if int(zyxk_tima) > 0:
                zyxk_time = int(zyxk_tima)
                break
        print("[输入不正确]：请重新输入")
    os.system('cls')
    os.system('color 8f')
    zyxk_flag = 0
    print("")
    print("----------------------------------------------正在抢课-----------------------------------------------")
    print()
    print()
    print()
    print("-----------------------------------------------------------------------------------------------------")
    print("#     课程名       校区 课余量 位置   教室   开课时间 教师")
    print("-----------------------------------------------------------------------------------------------------")
    print()
    zyxk_coun = 0
    global zyxk_lass
    zyxk_lass = time.time()
    zyxk_begi = time.time()
    while zyxk_flag == 0:
        zyxk_coun = zyxk_coun+1
        os.system('color 8f')
        time.sleep(zyxk_time - 1)
        try:
            zyxk_datr = http_main.get(http_urls_zyxk)
        except:
            print("[严重的错误]：网络连接中断，请确保网络稳定")
            continue
        try:
            zyxk_data = http_main.post(http_urls_kclb, post_data)
        except:
            print("[严重的错误]：网络连接中断，请确保网络稳定")
            continue
        if zyxk_coun%5==0:
            os.system('cls')
            if zyxk_datr.status_code==200:
                zyxk_nets = '200-正常'
            else:
                zyxk_nets = str(zyxk_datr.status_code)+'-错误'
            zyxk_allt = str((time.time()-zyxk_begi)//3600)+"时"+str(((time.time()-zyxk_begi)%3600)//60)+"分"+str(((time.time()-zyxk_begi)%60//1))+"秒"
            zyxk_lxzq = str(int((time.time()-zyxk_lass)*200))
            zyxk_lass = time.time()
            print("----------------------------------------------正在抢课-----------------------------------------------")
            print()
            print(" 当前次数：", zyxk_coun, " 网络状态：", zyxk_nets, " 总共耗时", zyxk_allt, "轮询速度："+zyxk_lxzq+"ms/次"+" 设定速度："+str(zyxk_time)+"s/次")
            print()
            print("-----------------------------------------------------------------------------------------------------")
            print("#     课程名       校区 课余量 位置   教室   开课时间 教师")
            print("-----------------------------------------------------------------------------------------------------")
        zyxk_tabs = json.loads(zyxk_data.text)
        zyxk_list = json.loads(zyxk_tabs['rwRxkZlList'])
        zyxk_nums = 0
        for zyxk_loop in zyxk_list:
            zyxk_nums += 1
            if zyxk_dat1 == zyxk_loop['kcm'] \
                    and zyxk_dat2 == zyxk_loop['jasm'] \
                    and zyxk_dat3 == zyxk_loop['skjs']:
                print(str(zyxk_nums).rjust(2, ' '),
                      zyxk_loop['kcm'][0:8].rjust(8, ' '),
                      zyxk_loop['kkxqm'].ljust(2, ' '),
                      str(zyxk_loop['bkskyl']).rjust(3, ' '),
                      zyxk_loop['jxlm'][0:4].ljust(4, ' '),
                      zyxk_loop['jasm'][0:4].ljust(4, ' '),
                      end="")
                zyxk_chls = False
                for ch in zyxk_loop['jasm'][0:4]:
                    if u'\u4e00' <= ch <= u'\u9fff':
                        zyxk_chls = True
                if zyxk_chls == False:
                    print("\t", end="")
                print(zyxk_loop['sjdd'][0]['zcsm'].rjust(6, ' '),
                      zyxk_loop['skjs'][0:3].ljust(3, ' ')
                      )
                if int(zyxk_loop['bkskyl']) > 0:
                    zxyk_name = ""
                    for i in range(0, len(zyxk_loop['kcm'])):
                        zxyk_name += str(int((hex(ord(zyxk_loop['kcm'][i])).zfill(4)), 16)) + ","
                    zxyk_temp = zyxk_datr.text.find('id="tokenValue"')
                    zxyk_toke = zyxk_datr.text[zxyk_temp + 23:zxyk_temp + 55]
                    zxyk_post = {
                        "dealType": 5,
                        "kcIds": zyxk_loop['kch'] + "_" + zyxk_loop['kxh'] + "_" + zyxk_loop['zxjxjhh'],
                        "kcms": zxyk_name,
                        "fajhh": zyxk_fxid,
                        "sj": "0_0",
                        "searchtj": zdqk_inpu,
                        "kclbdm": "",
                        "inputCode": "",
                        "tokenValue": zxyk_toke
                    }
                    zyxk_data = http_main.post(http_urls_post, zxyk_post)
                    os.system('cls')
                    if zyxk_data.text.find("ok") != -1:
                        os.system('color 2f')
                        print()
                        print()
                        print("                                       ■■■■■■■■■■■")
                        print("                                       ■                  ■")
                        print("                                       ■      抢课成功    ■")
                        print("                                       ■                  ■")
                        print("                                       ■■■■■■■■■■■")
                        print("[指令发送OK]：仅表示成功提交，不保证抢到")
                        print("[指令发送OK]：如果失败，可能是别人先提交")
                        print()
                    else:
                        os.system('color 4f')
                        print()
                        print()
                        print("                                       ■■■■■■■■■■■")
                        print("                                       ■                  ■")
                        print("                                       ■      抢课失败    ■")
                        print("                                       ■                  ■")
                        print("                                       ■■■■■■■■■■■")
                        print()
                        print("----------------------------------------------5s后重试-----------------------------------------------")
                        time.sleep(5)
                        zyxk_flag = 0
                        os.system('cls')
                        break
                    print(zyxk_data.text)
                    zyxk_flag = 1
                    break
    input("--------------------------------------------按回车键返回---------------------------------------------")
