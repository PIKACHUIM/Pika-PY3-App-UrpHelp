import requests
http_main = requests.session()
http_week = ['一', '二', '三', '四', '五', '六', '日','  ']
http_urls_zyxk = "http://zhjw.scu.edu.cn/student/courseSelect/courseSelect/index"
http_urls_xkl1 = "http://zhjw.scu.edu.cn/student/courseSelect/courseSelectResult/index"
http_urls_xkl2 = "http://zhjw.scu.edu.cn/student/courseSelect/thisSemesterCurriculum/callback"
http_urls_jdjs = "http://zhjw.scu.edu.cn/student/integratedQuery/scoreQuery/coursePropertyScores/index#id_1"
http_urls_jddt = "http://zhjw.scu.edu.cn/student/integratedQuery/scoreQuery/coursePropertyScores/callback"
http_urls_kclb = "http://zhjw.scu.edu.cn/student/courseSelect/freeCourse/courseList"
http_urls_post = "http://zhjw.scu.edu.cn/student/courseSelect/selectCourse/checkInputCodeAndSubmit"
http_head = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1"}